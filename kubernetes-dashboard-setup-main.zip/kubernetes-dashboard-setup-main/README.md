# kubernetes-dashboard-setup

>To setup dashboard apply the dashboard.yaml which is given in repo [here](http://gitlab.products.kiya.ai/platform-km/kubernetes-dashboard-setup/-/blob/main/dashboard.yaml)

```
kubectl apply -f <dashboard.yaml>
```
> check service is running or not in kubernetes-dashboard namespace 
```
kubectl get all -n kuberntes-dashboard
```
>go to terminal where kubectl is deploy 
```
kubectl proxy
```
>After that you can see the dashboard at 
```
http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/
```
>for login follow this steps:
>create secret or get secret from kube-system namespace and copy that token paste in token section 
```
 kubectl -n kube-system get secret
 kubectl -n kube-system describe secret secret-name
 ```
