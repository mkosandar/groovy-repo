# SonarQube-setup



> Follow the compsoe file for setup SonarQube on docker [here](http://gitlab.products.kiya.ai/platform-km/sonarqube-setup/-/blob/main/sonarqube-compose.yaml)


# Add this command where sonarqube is setup. 
```
go to /etc/sysctl.conf   
vm.max_map_count=262144
add command in this file
sudo sysctl -p
```
