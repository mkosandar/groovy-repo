# step-by-step guide to setup a kubernetes cluster using Kubeadm.

- **Kubeadm Setup Prerequisites**
    - Minimum two Ubuntu nodes [One master and one worker node]. You can have more worker nodes as per your requirement.
    - The master node should have a minimum of 2 vCPU and 2GB RAM.
    - For the worker nodes, a minimum of 1vCPU and 2 GB RAM is recommended.
    - 10.X.X.X/X network range with static IPs for master and worker nodes. We will be using the 192.x.x.x series as the pod network range that will be used by the Calico network plugin. Make sure the Node IP range and pod IP range don’t overlap.

- Disableing firewall of nodes `sudo ufw disable`

- Kubeadm Port Requirements
    - Please refer to the following [**image**](http://gitlab.products.kiya.ai/platform-km/kubernetes-cluster-setup/-/blob/main/kuberetes-port-requirements-min.png.webp) and make sure all the ports are allowed for the control plane (master) and the worker nodes.

- Enable iptables Bridged Traffic on all the Nodes.

- Execute the following commands on all the nodes for IPtables to see bridged traffic.
```
cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF

sudo modprobe overlay
sudo modprobe br_netfilter

# sysctl params required by setup, params persist across reboots
cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF

# Apply sysctl params without reboot
sudo sysctl --system
```

- Disable swap on all the Nodes
    - For kubeadm to work properly, you need to disable swap on all the nodes using the following command.
```
sudo swapoff -a
(crontab -l 2>/dev/null; echo "@reboot /sbin/swapoff -a") | crontab - || true
```
- The fstab entry will make sure the swap is off on system reboots.
- Reboot your system.


- Install Docker On All The Nodes.
- Set up the repository:
```
sudo apt-get update

sudo apt-get install \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

```

- Add Docker’s official GPG key:
```
sudo mkdir -m 0755 -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
```

- Use the following command to set up the repository:
```
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

```
- Install Docker Engine
```
sudo apt-get update

sudo chmod a+r /etc/apt/keyrings/docker.gpg
sudo apt-get update
```
- Install Docker Engine, containerd, and Docker Compose.
```
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```
- Manage Docker as a non-root user
```
 sudo groupadd docker
 sudo usermod -aG docker $USER
 newgrp docker
```
- Add configuration in docker to pull image from insecure registries.
- edit conf-file: sudo nano /etc/docker/daemon.json
```
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "insecure-registries" : ["172.21.0.66:5000","172.21.0.66:5001"],
  "storage-driver": "overlay2"
}

```
- Restart docker service :
```
systemctl restart docker
```
- Install Kubeadm & Kubelet & Kubectl on all Nodes
- Install the required dependencies.
```
sudo apt-get update
sudo apt-get install -y apt-transport-https ca-certificates curl
sudo curl -fsSLo /usr/share/keyrings/kubernetes-archive-keyring.gpg https://packages.cloud.google.com/apt/doc/apt-key.gpg
```
- Add the GPG key and apt repository.
```
echo "deb [signed-by=/usr/share/keyrings/kubernetes-archive-keyring.gpg] https://apt.kubernetes.io/ kubernetes-xenial main" | sudo tee /etc/apt/sources.list.d/kubernetes.list
```
- Update apt and install the latest version of kubelet, kubeadm, and kubectl.
```
sudo apt-get install -y kubelet=1.26.1-00 kubectl=1.26.1-00 kubeadm=1.26.1-00  // check for the latest stable version
```
- Add hold to the packages to prevent upgrades.
```
sudo apt-mark hold kubelet kubeadm kubectl
```
- Initialize Kubeadm On Master Node To Setup Control Plane
```
sudo kubeadm init --apiserver-advertise-address=172.21.0.63 --pod-network-cidr=192.168.0.0/16

```
- On a successful kubeadm initialization, you should get an output with kubeconfig file location and the join command with the token
- Use the following commands from the output to create the kubeconfig in master so that you can use kubectl to interact with cluster API.
```
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
```
- Now, verify the kubeconfig by executing the following kubectl command to list all the pods in the kube-system namespace.
```
kubectl get po -n kube-system
```
- You can get the cluster info using the following command.
```
kubectl cluster-info 
```

- Install Calico Network Plugin for Pod Networking
- I am using the Calico network plugin for this setup.
- Execute the following command to install the calico network plugin on the cluster.
```
kubectl apply -f https://docs.projectcalico.org/v3.14/manifests/calico.yaml
```
- Join Worker Nodes To Kubernetes Master Node
- Print join command to join worker node
```
kubeadm token create --print-join-command
```

- To check all nodes are ready  
```
kubectl get nodes
```
