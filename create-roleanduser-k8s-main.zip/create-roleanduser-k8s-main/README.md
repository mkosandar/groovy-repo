# create-RoleandUser-K8s


 Creating Users and Roles

Generating private key for John (john.key)
```
openssl genrsa -out john.key 2048
```
Generating certificate signing request (john.csr)
```
openssl req -new -key john.key -out john.csr -subj "/CN=john/O=finance"
```
Copy kubernetes ca certificate and key from the master node kmaster

Sign the certificate using certificate authority
```
openssl x509 -req -in john.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out john.crt -days 365
```
```
kubectl --kubeconfig all-developer.kubeconfig config set-cluster kubernetes server https://clusterip:6443 --certif1cate-authority=ca.crt
```
edit config file and put all certificate in file for follow below steps 
```
1.kubectl --kubeconfig all-developer.kubeconfig config set-credentials all-developer --client-certificate <location>/all-developer.crt --client-key <location>/all-developer.key 

2.kubectl --kubeconfig all-developer.kubeconfig config set-context all-developer-kubernetes --cluster kubernetes --namespace=<namespace> --user all-developer
```
```
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=aml-prod
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=cbs-prod
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=los-prod
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=common-prod
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=lcs-prod
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=angular-prod

kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=aml-prod
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=cbs-prod
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=los-prod
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=common-prod
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=lcs-prod
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=angular-prod

kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=aml-dev
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=cbs-dev 
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=los-dev 
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=common-dev
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=lcs-dev
kubectl create role all-developer --verb=get,list --resource=pods,pods/status,pods/log --namespace=angular-dev

kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=aml-dev
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=cbs-dev
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=los-dev
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=common-dev
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=lcs-dev
kubectl create rolebinding all-developer-rolebinding --role=all-developer --user=all-developer --namespace=angular-dev


```
