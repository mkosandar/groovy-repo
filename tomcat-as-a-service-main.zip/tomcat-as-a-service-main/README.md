# Tomcat-as-a-service


install tomcat as service 

- Download from here https://tomcat.apache.org/download-90.cgi 
- See the image ![image](http://gitlab.products.kiya.ai/platform-km/tomcat-as-a-service/-/raw/main/Screenshot_2023-06-05_121521.png)
- double click and install tomcat as a service 
- If you want increase the jvm heap size follow this steps:
- Open service.bat in notepad which is located at `<Tomcat-location>/Tomcat/bin`
- Search for jvmMs and make changes as per your requirements see image given below 
- ![image](http://gitlab.products.kiya.ai/platform-km/tomcat-as-a-service/-/raw/main/Screenshot_2023-06-05_122447.png)

- if you download zip file then follow this steps:
- Open CMD at ` <Tomcat-location>/Tomcat/bin`
- run this command 
```
service.bat install <your_service_name>
```
- Go to services and check the tomcat service is installed or not.
- Change the service properties to automatic 


# NOTE:

- If you want to delete your tomcat service follow this steps:
- Press the Win + R keys to open Run, type regedit into Run, and click/tap on OK to open Registry Editor or Click Start and search registry Editor.
- ![image](http://gitlab.products.kiya.ai/platform-km/tomcat-as-a-service/-/raw/main/Screenshot_2023-06-05_133729.png)
- Navigate to the registry key below in the left pane of Registry Editor.
    - HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services
- Under the Services key, right click or press and hold on the service name (ex: "Example Service"). See following image.
- ![image](http://gitlab.products.kiya.ai/platform-km/tomcat-as-a-service/-/raw/main/Screenshot_2023-06-05_133424.png)
- Click/tap on Yes to confirm.
- When finished, close Registry Editor.
- Restart the computer to apply







