def call(){
    if (fileExists('build.gradle')) {
        sh "gradle clean build --no-daemon"
        //sh "gradle clean build jacocoTestReport"
        //sh "gradle clean build cyclonedxBom"
    } else if (fileExists('package.json')){
        sh "npm install  "//--force
        sh "npm run build --prod"
    } else if (fileExists('pom.xml')){
        sh "mvn clean install -DskipTests"
    }
}

