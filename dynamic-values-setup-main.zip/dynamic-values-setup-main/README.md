# dynamic-values-setup

- To change the application-properties as per your deployment.
- Example for devlopment and production.
- You have to define properties in **data** section of values.yaml
- [Your values.yaml look like ](http://gitlab.products.kiya.ai/platform-km/dynamic-values-setup/-/blob/main/values.jpg)
- in that file add properties. [for referance](http://gitlab.products.kiya.ai/platform-km/dynamic-values-setup/-/tree/main/values)
- Your values.yaml name shoud be like **values-prod.yaml** (for production) or **values-dev.yaml**
