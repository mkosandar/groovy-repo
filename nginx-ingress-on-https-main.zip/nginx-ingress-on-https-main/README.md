# nginx-ingress-on-https

**How to setup nginx-ingress-controller ??**

- There are multiple way you can setup through **manifests file** or using **helm chart** 

- follow this link to setup : [nginx-ingress-controller](https://docs.nginx.com/nginx-ingress-controller/installation/installation-with-manifests/)


After setup follow this steps to setup **nginx-ingress-controller** with **HTTPS** 

- First you have to generate self-sign certificate and key using **OPENSSL** [use this reference](https://www.baeldung.com/openssl-self-signed-cert)

- Save that cert and key where kubectl is running.

- The kubectl CLI provides a command to easily store TLS certificate key-pairs in Kubernetes as secrets.

- Create secret for all NAMESPACE

- For reference 
    `kubectl create secret tls <SECRET-NAME> --cert=<PATH/TO/CERT/FILE> --key=<PATH/TO/KEY/FILE> -n <NAMESPACE>`

- Add the TLS part in ingress.yaml
```
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ .Values.projectName }}-ingress
spec:
  ingressClassName: nginx
  rules:
  - host: {{ .Values.host }}
    http:
      paths:
        - pathType: Prefix
          path: "/"
          backend:
            service:
              name: {{ .Values.projectName }}
              port:
                number: {{ .Values.service.port }}
  tls:
  - hosts:
    - {{ .Values.host }}
    secretName: nginx-ingress-cert
```
- Use this ingress.yaml in your service. 

