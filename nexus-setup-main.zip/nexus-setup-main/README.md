# nexus-setup


> Follow the compose file for **nexus** setup on docker [here](http://gitlab.products.kiya.ai/platform-km/nexus-setup/-/blob/main/nexus-compose.yaml)
