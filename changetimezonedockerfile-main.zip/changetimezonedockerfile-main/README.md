# ChangeTimeZoneDockerFile


- exec into docker container and check if **tzdata** or **tzselect** package is installed or not.
```
docker exec -it <container-id> /bin/sh
```
- Check package at location:
```
cd /bin
ls -ltrh
```
- If it is install then add this command in your dockerfile:
```
ENV TZ=Asia/Kolkata
```
- If **tzdata** or **tzselect** pacakge is not install then add this command in your dockerfile.
```
RUN apk add --no-cache tzdata
ENV TZ=Asia/Kolkata

```
