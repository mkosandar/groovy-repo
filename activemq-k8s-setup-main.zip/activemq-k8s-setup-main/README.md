# ActiveMQ-k8s-setup



**CREATE DATABASE FOR ActiveMQ**

- for database you can use MYSQL docker container.
- check the mysql-docker-compose.yaml file. [click here](http://gitlab.products.kiya.ai/platform-km/activemq-k8s-setup/-/blob/main/docker/mysql-compse.yaml)
- Login into mysql database.
- After creating db grant all permisson to activemq user.
    - CREATE USER 'activemq'@'%' IDENTIFIED BY 'your_password';
    - GRANT ALL ON activemq.* TO 'activemq'@'%';

**Configuring JDBC**

- Modify [activemq.xml](http://gitlab.products.kiya.ai/platform-km/activemq-k8s-setup/-/blob/main/docker/activemq.xml)
- persistence adapter to configure a JDBC connection to MySQL.
>     <persistenceAdapter>  
>       <jdbcPersistenceAdapter dataDirectory="${activemq.base}/data" dataSource="#mysql-ds"/>
>     </persistenceAdapter>  


- Then, just after the ending broker element `(</broker>)` add the following bean
>     <bean id="mysql-ds" class="org.apache.commons.dbcp2.BasicDataSource" destroy-method="close">
>         <property name="driverClassName" value="com.mysql.jdbc.Driver"/>
>         <property name="url" value="jdbc:mysql://172.21.0.126:3306/activemq?relaxAutoCommit=true"/>
>         <property name="username" value="activemq"/>
>         <property name="password" value="activemq123"/>
>         <property name="poolPreparedStatements" value="true"/>
>     </bean>



**BUILD ActiveMQ IMAGE ON docker**

- Apache doesn’t publish a canonical Docker image for ActiveMQ, so we can build our own. Use the following minimal Dockerfile for a reference.[Click here](http://gitlab.products.kiya.ai/platform-km/activemq-k8s-setup/-/blob/main/docker/Dockerfile)
- After creating that docker image push to nexus repository.(for backup)

**DEPLOY ON KUBERNETES**

- Check all yaml files(deployment,service and ingress). [Click here](http://gitlab.products.kiya.ai/platform-km/activemq-k8s-setup/-/tree/main/kubernetes)
- Create NAMESPACE active-mq
- Deploy all yaml. example(**kubectl apply -f activemq-deployment.yaml -n active-mq**)
