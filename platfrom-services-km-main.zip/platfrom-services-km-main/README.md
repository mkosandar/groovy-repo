# platfrom-services-km



This project is created to maintain live KM documents related to the services created as part of Finairo development.

- centralized service
- reporting service
