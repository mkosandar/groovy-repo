# SecureTomcatJDBC

- Start the Script SecureTomcatJDBC.sh
- Enter the $CATALINA_HOME(your tomcat directory path) directory as an Input and JAVA_HOME and All other Required Parameters will be auto fetched
- Enter the Password to Encrypt including the Pass Phrase
- Copy the Generated SecureTomcatJDBC.jar into the $CATALINA_HOME/lib directory
- Replace the Factory element in server.xml with factory=“SecureTomcatDataSourceImpl”
- Replace the Encrypted Password in place of Clear Text Password password="ENCRYPTED PASSWORD”

For further reference https://www.middlewareinventory.com/blog/secure-tomcat-jdbc/
