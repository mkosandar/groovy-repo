#downgrade linux cgroup version 

- use `docker info` command for check cgroup version 
- use cgroup version v2 which is recommended.
- If you want to change or downgrade the cgroup version follow this steps(for linux only):
- first open grub file which is located at /etc/default/grub
- `sudo nano /etc/default/grub`
- add the following line 
- `GRUB_CMDLINE_LINUX="systemd.unified_cgroup_hierarchy=false"`
- save and exit file 
- reboot the system 
- and check docker version 
