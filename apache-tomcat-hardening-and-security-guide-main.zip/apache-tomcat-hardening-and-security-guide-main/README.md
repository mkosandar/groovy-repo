# apache-tomcat-hardening-and-security-guide



## Getting started

- **Remove extraneous files and directories**
    - Removing sample resources is a defense in depth measure that reduces potential exposures introduced by these resources.
    - The installation may provide example applications, documentation, and other directories 
which may not serve a production use.
    - `rm -rf webapps/examples webapps/docs webapps/ROOT`
    - If the Manager and HOST-Manager application are not utilized, also remove the 
following resources
    - `rm -rf webapps/host-manager webapps/manager`
    - **Disable Unused Connectors**
        - The default installation of Tomcat includes connectors with default settings. These are 
    traditionally set up for convenience. It is best to remove these connectors and enable 
    only what is needed
        - `grep “Connector” conf/server.xml`
        - Within the conf/server.xml, remove, or comment out, each unused Connector. For example, to disable an instance of the HTTPConnector, remove the following:
        - 
        ```
            <Connector className="org.apache.catalina.connector.http.HttpConnector" 
            ...
            connectionTimeout="60000"/>
        ```
- **Limit Server Platform Information Leaks**
    - **Alter the Advertised server.info String/Alter the Advertised server.number/Alter the Advertised server.built Date**
        - The server.info attribute contains the name of the application service. This value is 
presented to Tomcat clients when clients connect to the tomcat server.
        -  Perform the following to alter the server platform string that gets displayed when clients 
connect to the tomcat server.

        1. Extract the ServerInfo.properties file from the catalina.jar file:
        ```
        cd lib
        jar xf catalina.jar org/apache/catalina/util/ServerInfo.properties
        ```
        2. Navigate to the util directory that was created
        ```
        cd org/apache/catalina/util
        ```
        3. Open ServerInfo.properties in an editor
        4. Update the server.info attribute in the ServerInfo.properties file.
        ```
        server.info=<SomeWebServer>
        server.number=<Someserver.number>
        server.built= <Someserver.built Date>
        ```
        5. Update the catalina.jar with the modified ServerInfo.properties fil
        ```
        jar uf catalina.jar org/apache/catalina/util/ServerInfo.properties
        ```



