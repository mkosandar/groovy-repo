def call (String ip, list, volume=null) {
    verCode = UUID.randomUUID().toString()
    def javaHome ="${env.JAVA_HOME}"
    def artifactIdLowerCase
    def baseImage
    if (fileExists('build.gradle')||fileExists('pom.xml')){
        if (javaHome.contains("JDK11")){
            baseImage="adoptopenjdk/openjdk11"
            //baseImage="172.21.0.66:5000/openjdk:11"
        }
        else if (javaHome.contains("JDK17")){
            baseImage="openjdk:17.0.2-jdk"
            //baseImage="172.21.0.66:5000/openjdk:17"
        }
        else if  (javaHome.contains("JDK8")){
            baseImage="adoptopenjdk/openjdk8"
            //baseImage="172.21.0.66:5000/openjdk:8"
        }
    } else if (fileExists('package.json')){
        baseImage="nginx:1.23.1-alpine"
    }
    
     if (fileExists('build.gradle')) {
        def props = readProperties file: 'gradle.properties'
        def artifactId = props['artifactId']
        artifactIdLowerCase = artifactId.toLowerCase()
        def version = props['version']
        sh "docker build  -t 172.21.0.66:5000/"+"${artifactIdLowerCase}"+":"+"${verCode} --build-arg image=${baseImage} --build-arg jar=${artifactIdLowerCase}-${version}.jar --build-arg jarpath=build/libs/ ."
        sh "docker push 172.21.0.66:5000/"+"${artifactIdLowerCase}"+":"+"${verCode}"
        sh "docker rmi 172.21.0.66:5000/"+"${artifactIdLowerCase}"+":"+"${verCode}"+ " &> /dev/null || true"
    } else if (fileExists('pom.xml')){
        pom = readMavenPom file: 'pom.xml'
        String artifactId = "${pom.artifactId}"; 
        artifactIdLowerCase = artifactId.toLowerCase()
        sh "docker build  -t 172.21.0.66:5000/"+artifactIdLowerCase+":"+"${verCode} --build-arg jar="+artifactIdLowerCase+"-${pom.version}.jar --build-arg image=${baseImage} --build-arg jarpath=target/ . "
        sh "docker push 172.21.0.66:5000/"+artifactIdLowerCase+":"+"${verCode}"
        sh "docker rmi 172.21.0.66:5000/"+artifactIdLowerCase+":"+"${verCode}"
    } else if (fileExists('package.json')){
        def props = readJSON file: 'package.json'
        def name = props["name"]
        artifactIdLowerCase = name
        def version = props["version"]
        sh "docker build . -t 172.21.0.66:5000/"+"${name}"+":"+"${verCode}"
        sh "docker push 172.21.0.66:5000/"+"${name}"+":"+"${verCode}"
        sh "docker rmi 172.21.0.66:5000/"+"${name}"+":"+"${verCode}"
    }


    def image
    def artifactId
    def String berforeLowerCaseArtifactId
    def String afterLowerCaseArtifactId
      if (fileExists('build.gradle')) {
      def props = readProperties file: 'gradle.properties'
      berforeLowerCaseArtifactId = props['artifactId']
      afterLowerCaseArtifactId = berforeLowerCaseArtifactId.toLowerCase()
      def version = props['version']
      image= "172.21.0.66:5000/"+afterLowerCaseArtifactId+":"+"${verCode}"
      sh "echo $image"
   } else if (fileExists('pom.xml')){
      pom = readMavenPom file: 'pom.xml'
      berforeLowerCaseArtifactId = "${pom.artifactId}"; 
      afterLowerCaseArtifactId = berforeLowerCaseArtifactId.toLowerCase()
      image="172.21.0.66:5000/"+afterLowerCaseArtifactId+":"+"${verCode}"
	  sh "echo $image"
   } else if (fileExists('package.json')){
      def props = readJSON file: 'package.json'
      def name = props["name"]
      def version = props["version"]
      berforeLowerCaseArtifactId= "${name}"
	  afterLowerCaseArtifactId = berforeLowerCaseArtifactId.toLowerCase()
      image="172.21.0.66:5000/"+afterLowerCaseArtifactId+":"+"${verCode}"
      sh "echo $image"

   }
   def String a=""
   for(int i=0;i<list.size();i++)
      {
      
         a =  a + ' -p ' + list.get(i) 
      }
   sh "echo ${a}"

   def String dockerCommand=""
   def String dockerCommandPart1="docker run --name ${afterLowerCaseArtifactId} -d ${a}"
   def String dockerCommandPart2=""
   def String dockerCommandPart3=" ${image}"
    if(volume!=null){
        def String volumeDir=""
        for(int i=0;i<volume.size();i++)
        {
            volumeDir =  volumeDir + ' -v ' + volume.get(i) 
        }
        sh "echo ${volumeDir}"
        dockerCommandPart2= "${volumeDir}"
    }
    else if (volume==null){
        dockerCommandPart2= " "
    }

    dockerCommand= dockerCommandPart1 + dockerCommandPart2 + dockerCommandPart3
    sh "echo ${dockerCommand}"
// docker run --name $afterLowerCaseArtifactId -d ${a} ${loglocation} ${image}
   sshPublisher(publishers: [sshPublisherDesc(configName: "${ip}", transfers: [sshTransfer(cleanRemote: false, excludes: '', execCommand: " docker rm -f $afterLowerCaseArtifactId; docker rmi -f ${image}; ${dockerCommand} ", execTimeout: 120000, flatten: false, makeEmptyDirs: false, noDefaultExcludes: false, patternSeparator: '[, ]+', remoteDirectory: '', remoteDirectorySDF: false, removePrefix: '', sourceFiles: '')], usePromotionTimestamp: false, useWorkspaceInPromotion: false, verbose: true)])
}
