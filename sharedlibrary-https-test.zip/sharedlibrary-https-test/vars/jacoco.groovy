def call(jacoco) {
    sh "jacoco classPattern: './build/classes', execPattern: './build/jacocoTestReport/test/jacocoTestReport.xml', sourcePattern: './src/main/java' "
}
