def call(String port = 8083, String projectType = "gradle") {
    if(projectType == "gradle") {
        def props = readProperties file: 'gradle.properties'
        def artifactId = props['artifactId']
        def version = props['version']
        sh "docker pull 172.21.0.66:5000/${artifactId}:${version}"
        sh "docker run -d -p ${port}:${port} 172.21.0.66:5000/${artifactId}:${version}"
    } else {
        pom = readMavenPom file: 'pom.xml'
        sh "docker pull 172.21.0.66:5000/${pom.artifactId}:${pom.version}"
        sh "docker run -d -p ${port}:${port} 172.21.0.66:5000/${pom.artifactId}:${pom.version}"
    }
}
