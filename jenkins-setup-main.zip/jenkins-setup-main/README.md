For setup jenkins check user-handbook for installation steps
