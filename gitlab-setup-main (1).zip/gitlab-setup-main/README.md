# Gitlab-setup


Follow the docker-compsoe file to setup gitlab on docker which is given [here](http://gitlab.products.kiya.ai/platform-km/gitlab-setup/-/blob/main/gitlab-compsoe.yaml) 


# Gitlab-Backup

```
 docker exec -t <container name> gitlab-backup create
```
It will cretae backup at /var/opt/gitlab/backup

# Gitlab-backup restore

For both these installation types, the backup tarball has to be available in the backup location (default location is /var/opt/gitlab/backups).

For Docker installations, the restore task can be run from host:

# Stop the processes that are connected to the database
```
docker exec -it <name of container> gitlab-ctl stop puma
docker exec -it <name of container> gitlab-ctl stop sidekiq
```


# Verify that the processes are all down before continuing
```
docker exec -it <name of container> gitlab-ctl status
```

# Run the restore
```
docker exec -it <name of container> gitlab-backup restore BACKUP=11493107454_2018_04_25_10.6.4-ce
```

# Restart the GitLab container
```
docker restart <name of container>
```

# Check GitLab
```
docker exec -it <name of container> gitlab-rake gitlab:check SANITIZE=true

```
