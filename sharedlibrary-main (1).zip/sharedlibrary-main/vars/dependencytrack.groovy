def call (){
    dependencyCheck additionalArguments: ''' 
    -o "./" 
    -s "./"
    -f "ALL" 
    --prettyPrint''', odcInstallation: 'Dependency'
    dependencyCheckPublisher pattern: 'dependency-check-report.xml'
}
