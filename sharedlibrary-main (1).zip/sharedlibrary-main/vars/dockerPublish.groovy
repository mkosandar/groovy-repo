def call() {
    sh "echo This script is deprecated as publish logic has been merged with deployment step. Please remove this stage from your Jenkinsfile."
}
