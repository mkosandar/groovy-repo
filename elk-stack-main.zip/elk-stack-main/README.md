# elk-stack

- kibana is basically used for visualize logs.
- kibana URL: kibana-products.kiya.ai
- Add the URL in your host file to access.

**HOW TO SETUP HOSTFILE**

- Open your text editor in Administrator mode.
- In the text editor, open C:\Windows\System32\drivers\etc\hosts.
- Add the IP Address and hostname.
- 172.21.0.63 kibana-products.kiya.ai
- Save the changes.

 
**HOW TO CHANGE THE VIEW OF COLUMNS**

- Open kibana ui ([kibana-url](http://kibana-products.kiya.ai/)) 
- Dashboard look like this http://gitlab.products.kiya.ai/platform-km/elk-stack/-/blob/main/kibana.jpg
- Go to discover sidebar
- In Available Fields you can add multiple Fields like (message, kubernetes.container.name, kubernetes.namespace etc.)
- http://gitlab.products.kiya.ai/platform-km/elk-stack/-/blob/main/fields.jpg
- If you look at the picture in green box they are selected fields. 
- That Black box is showing the view after selecting the fields.
- You can select field as per your choice to view logs.

**HOW TO APPLY FILTER**

- To view specific service log there is a button **Add a filter** on left top.
- In that box choose your filter for example.  
- http://gitlab.products.kiya.ai/platform-km/elk-stack/-/blob/main/add-filter.jpg
- Click to save button to apply filter.
- After adding a filter your logs for specific service look like this.
- http://gitlab.products.kiya.ai/platform-km/elk-stack/-/blob/main/afteradding-filter.jpg
- To change the **Time Range** you have click on top right corner. (Last 15 minutes, Last 30 minutes, Last 1 hour etc.)
