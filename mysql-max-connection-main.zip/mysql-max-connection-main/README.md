# mysql-max-connection

- Create mysql instance.
- I'm using mysql docker container.
- To enter mysql container follow this steps:
    - How do I run an exec container?
    - Use docker ps to get the name of the existing container.
    - Use the command docker exec -it <container name> /bin/bash to get a bash shell in the container.
    - Generically, use docker exec -it <container name> <command> to execute whatever command you specify in the container.
    - Example:docker exec -it 08wbsedcsh /bin/sh
- Go to /etc/mysql/my.cnf
- Add the command 
```
    [mysqld]
    max_connections = 1000
```
#Add mysql_connection as per your need. 

 
