def call(){
    if (fileExists('Dockerfile')){
        echo "Dockerfile already exists."
    }
    else {
        echo "Dockerfile does not exist, downloading..."
        sh "rm -rf Dockerfile"
        if (fileExists('build.gradle') || fileExists('pom.xml')){
            sh "rm -rf Dockerfile"
            sh " wget -O Dockerfile http://gitlab.products.kiya.ai/mayuresh.kosandar/dockerfile/-/raw/main/dockerfile-java"
        } else if (fileExists('package.json')){
            sh "rm -rf Dockerfile"
            sh " wget -O Dockerfile http://gitlab.products.kiya.ai/mayuresh.kosandar/dockerfile/-/raw/main/dockerfile-angular"
        }
    }
}
