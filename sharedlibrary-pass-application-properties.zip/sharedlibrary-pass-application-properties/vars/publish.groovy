def call(String projectType = "gradle") {
	if(projectType == "gradle") {
		def props = readProperties file: 'gradle.properties'
		def version = props['version']
		def type = props['type']
		def artifactId = props['artifactId']
		def groupId = props['groupId']
		String fileName = 'build/libs/'+artifactId+'-'+version+'.jar'
		def repository = 'maven-releases'
		if ("${version}".contains('SNAPSHOT')) {
		repository = 'maven-snapshots'
		}
		nexusArtifactUploader (
			nexusVersion: 'nexus3',
			protocol: 'http',
			nexusUrl: '172.21.0.66:8081',
			credentialsId: 'nexus',
			groupId: "${groupId}",
			version: "${version}",
			repository: "${repository}",
			artifacts: [
				[
					classifier: '',
					artifactId: "${artifactId}",
					type: "${type}",
					file: "${fileName}"
				]
			]
		)
	} else {
		pom = readMavenPom file: 'pom.xml'
		def repository = 'maven-releases'
		if (pom.version.contains('SNAPSHOT')) {
			repository = 'maven-snapshots'
		}
		String fileName = 'target/'+pom.artifactId+'-'+pom.version+'.jar'
		nexusArtifactUploader (
			nexusVersion: 'nexus3',
			protocol: 'http',
			nexusUrl: '172.21.0.66:8081',
			credentialsId: 'nexus',
			groupId: pom.groupId,
			version: pom.version,
			repository: "${repository}",
			artifacts: [
				[
					classifier: '',
					artifactId: pom.artifactId,
					type: 'jar',
					file: "${fileName}"
				]
			]
		)
	}
    
}
