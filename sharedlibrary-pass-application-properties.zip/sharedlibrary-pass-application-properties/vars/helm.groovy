def call() {
    verCode = UUID.randomUUID().toString()
    def javaHome ="${env.JAVA_HOME}"
    def artifactIdLowerCase
    def baseImage
    if (fileExists('build.gradle')||fileExists('pom.xml')){
         if (javaHome.contains("JDK11")){
            baseImage="adoptopenjdk/openjdk11"
            //baseImage="172.21.0.66:5000/openjdk:11"
        }
        else if (javaHome.contains("JDK17")){
            baseImage="openjdk:17.0.2-jdk"
            //baseImage="172.21.0.66:5000/openjdk:17"
        }
        else if  (javaHome.contains("JDK8")){
            baseImage="adoptopenjdk/openjdk8"
            //baseImage="172.21.0.66:5000/openjdk:8"
        }
    } else if (fileExists('package.json')){
        baseImage="nginx:1.23.1-alpine"
    }
    
     if (fileExists('build.gradle')) {
        def props = readProperties file: 'gradle.properties'
        def artifactId = props['artifactId']
        artifactIdLowerCase = artifactId.toLowerCase()
        def version = props['version']
        sh "docker build  -t 172.21.0.66:5000/"+"${artifactIdLowerCase}"+":"+"${verCode} --build-arg image=${baseImage} --build-arg jar=${artifactIdLowerCase}-${version}.jar --build-arg jarpath=build/libs/ ."
        sh "docker push 172.21.0.66:5000/"+"${artifactIdLowerCase}"+":"+"${verCode}"
        sh "docker rmi 172.21.0.66:5000/"+"${artifactIdLowerCase}"+":"+"${verCode}"+ " &> /dev/null || true"
    } else if (fileExists('pom.xml')){
        pom = readMavenPom file: 'pom.xml'
        String artifactId = "${pom.artifactId}"; 
        artifactIdLowerCase = artifactId.toLowerCase()
        sh "docker build  -t 172.21.0.66:5000/"+artifactIdLowerCase+":"+"${verCode} --build-arg jar="+artifactIdLowerCase+"-${pom.version}.jar --build-arg image=${baseImage} --build-arg jarpath=target/ . "
        sh "docker push 172.21.0.66:5000/"+artifactIdLowerCase+":"+"${verCode}"
        sh "docker rmi 172.21.0.66:5000/"+artifactIdLowerCase+":"+"${verCode}"
    } else if (fileExists('package.json')){
        def props = readJSON file: 'package.json'
        def name = props["name"]
        artifactIdLowerCase = name
        def version = props["version"]
        sh "docker build . -t 172.21.0.66:5000/"+"${name}"+":"+"${verCode}"
        sh "docker push 172.21.0.66:5000/"+"${name}"+":"+"${verCode}"
        sh "docker rmi 172.21.0.66:5000/"+"${name}"+":"+"${verCode}"
    }

    String str = "${env.GIT_URL}".split('/').last();
    def projectName = str.substring(0, (str.length()-4))
    def host= "${projectName}"
    echo "${env.GIT_BRANCH}"
    echo "${env.JOB_BASE_NAME}"
    echo "${env.JOB_NAME}"
    def namespace
    if("${env.JOB_NAME}".startsWith("cnpoc")) {
        namespace = "cnpoc"
    }
    if("${env.JOB_NAME}".startsWith("coe-cbs")) {
        namespace = "cbs"
    }
    if("${env.JOB_NAME}".startsWith("COE-AML")) {
        namespace = "aml"
    }
    if("${env.JOB_NAME}".startsWith("coe-los")) {
        namespace = "los"
    }
    if("${env.JOB_NAME}".startsWith("coe-lcs")) {
        namespace = "lcs"
    }
    if("${env.JOB_NAME}".startsWith("COE-EWS")) {
        namespace = "ews"
    }
    if("${env.JOB_NAME}".startsWith("COE-COMMON")) {
        namespace = "common"
    }
    if("${env.JOB_NAME}".startsWith("los-indostar")) {
        namespace = "los"
    }
    if("${env.JOB_NAME}".startsWith("UI-POC-Master")) {
        namespace = "angular"
    }
    if("${env.GIT_BRANCH}" == "main") {
        namespace = namespace + "-prod"
    }
    //else if("${env.GIT_BRANCH}" == "development" || "${env.GIT_BRANCH}" == "Development" || "${env.GIT_BRANCH}" == "develop" || "${env.GIT_BRANCH}" == "Develop" || "${env.JOB_NAME}".startsWith("UI-POC-Master") || "${env.JOB_NAME}".startsWith("cnpoc")) {
    else {
        namespace = namespace + "-dev"
    }
    host = host + "-" + namespace + ".kiya.ai"
    def dynamicvalue
    if("${env.GIT_BRANCH}" == "main") {
        dynamicvalue = "values-prod.yaml"
    }
    else {
        dynamicvalue = "values-dev.yaml"
    }
    
    sh "helm upgrade --install --atomic --timeout 100s -f \"${dynamicvalue}\" \"${projectName}\" helm/master-temp --namespace \"${namespace}\" --set projectName=\"${projectName}\",host=\"${host}\",image=\"172.21.0.66:5000/${artifactIdLowerCase}:${verCode}\" "

}
