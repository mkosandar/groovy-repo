def call() {
    def sonarqubeScannerHome = tool "sonar-scanner";
    def groupName = "${env.JOB_NAME}".split('/').first().toLowerCase();
	if (fileExists('build.gradle')) {
		def props = readProperties file: 'gradle.properties'
		def artifactId = props['artifactId']
        withSonarQubeEnv('sonarqube') {
            sh "${sonarqubeScannerHome}/bin/sonar-scanner -e -Dsonar.projectKey=${groupName}-${artifactId} -Dsonar.language=java -Dsonar.sources=src/main/java -Dsonar.coverage.exclusions=**/entities/** -Dsonar.java.binaries=build/classes -Dsonar.scm.disabled=true"
        }
        timeout(time: 10, unit: 'MINUTES') {
            waitForQualityGate abortPipeline: false
        }

	} else if (fileExists('pom.xml')) {
		pom = readMavenPom file: 'pom.xml'
        withSonarQubeEnv('sonarqube'){
            sh "${sonarqubeScannerHome}/bin/sonar-scanner -e -Dsonar.projectKey=${groupName}-${pom.artifactId} -Dsonar.language=java -Dsonar.sources=src/main/java -Dsonar.coverage.exclusions=**/entities/** -Dsonar.java.binaries=target/classes -Dsonar.scm.disabled=true"
	    }
        timeout(time: 10, unit: 'MINUTES') {
            waitForQualityGate abortPipeline: false
        }
    }
    
}
