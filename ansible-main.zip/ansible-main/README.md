Getting started with Ansible

    Ansible automates the management of remote systems and controls their desired state. A basic Ansible environment has three main components:

**Control node**
    A system on which Ansible is installed. You run Ansible commands such as ansible or ansible-inventory on a control node.

**Managed node**
    A remote system, or host, that Ansible controls.

**Inventory**
    A list of managed nodes that are logically organized. You create an inventory on the control node to describe host deployments to Ansible.

- Basic components of an Ansible environment include a control node, an inventory of managed nodes, and a module copied to each managed node.see this 
image. 
- ![image](http://gitlab.products.kiya.ai/platform-km/ansible/-/raw/main/Screenshot_2023-05-19_173943.png)


**Key Terms in Ansible**
- Controller Machine: This is where Ansible gets installed. The controller machine helps in enabling provisioning on servers we manage.
- Inventory: This is basically an initializing file that contains information about the servers that we are managing.
- Playbook: It is an organized unit of scripts defining an automated work for the configuration management of our server.
- Task: A task block defines a single procedure to be executed on the server like installing packages.
- Module: Basically, a module is a command or set of similar Ansible commands meant to be executed on the client-side
- Role: A way of organizing tasks and related files to be later called in a playbook


**Install ansible on Ubuntu/Debian systems**
- Step 1) Perform an update to the packages
```
 sudo apt update
```
- Install the software-properties-common package
```
sudo apt install software-properties-common
```
- Install ansible personal package archive
```
sudo apt-add-repository ppa:ansible/ansible
```
- Install ansible
```
sudo apt update
sudo apt install ansible
```
Create a file hosts and add remote systems how want to manage. As ansible relies on ssh to
connect the machines, you should make sure they are already accessible to you in ssh from your
computer.

**Setting Up the Inventory File**


- The inventory file contains information about the hosts you’ll manage with Ansible. You can include anywhere from one to several hundred servers in your inventory file, and hosts can be organized into groups and subgroups
- To edit the contents of your default Ansible inventory, open the /etc/ansible/hosts file using your text editor of choice, on your Ansible control node:
```
sudo nano /etc/ansible/hosts
```
- **Note: Although Ansible typically creates a default inventory file at etc/ansible/hosts, you are free to create inventory files in any location that better suits your needs. In this case, you’ll need to provide the path to your custom inventory file with the -i parameter when running Ansible commands and playbooks.**

Exp:
/etc/ansible/hosts
```
[users]
kiyavm46
kiyavm48

[masters]
kiyavm46 ansible_host=172.21.0.126 ansible_user=ansible

[workers]
kiyavm48 ansible_host=172.21.0.128 ansible_user=ansible
kiyavm47 ansible_host=172.21.0.127 ansible_user=ansible

```
**ansible-playbook** 
- See following of ansible-playbook 
- ![image](http://gitlab.products.kiya.ai/platform-km/ansible/-/raw/main/Screenshot_2023-05-19_180934.png))

Well, I have explained what each line does
- **name** Name of the playbook
- **hosts** A set of hosts usually grouped together as a host group and defined in inventory file
- **become** To tell ansible this play has to be executed with elevated privileges
- **become_user** the user name that we want to switch to like compare it with sudo su - user
- **tasks** set of tasks to execute, All tasks would be defined below this


**comman issue and problems in ansible**
- **Running in verbose mode**
    - Running the playbooks in debug mode can be the next step to get more details about what is happening in the tasks and variables.
    - From the command line, you can add -v (or -vv, -vvv, -vvvv, -vvvvv). The highest verbosity levels can sometimes be too much information, so it's better to increase gradually in multiple executions until you get what you need.
- **Problems connecting to your host**
    - If you are unable to run the helloworld.yml example playbook from the Quick Start Guide or other playbooks due to host connection errors, try the following:
        - Can you ssh to your host? Ansible depends on SSH access to the servers you are managing.
        - Are your hostnames and IPs correctly added in your inventory file? (Check for typos.)
- **Error Logs**
    - Tower server errors are logged in /var/log/tower. Supervisors logs can be found in /var/log/supervisor/. Apache web server errors are logged in the httpd error log. Configure other Tower logging needs in /etc/tower/conf.d/.
