# grafana-promethehus-setup on kubernetes cluster

- We are using helm for setup grafana, promethehus and etc.
- First we have to setup helm on our device.
- To install helm follow this link [Helm-Installaion](https://helm.sh/docs/intro/install/ )
- More about helm [Helm-Doc](https://helm.sh/docs/#welcome)
- After installing helm you have to add repo of kube-stack-metrics(for monitoring setup) in helm. Use this link for to add repo in your helm [kubernetes-package](https://artifacthub.io/)
- Search package in Search window. example (grafana, promethehus)
- They provide us setup command show in picture.[click here to view ](http://gitlab.products.kiya.ai/platform-km/grafana-promethehus-setup/-/blob/main/images/package.jpg)
- Install helm chart on your cluster using helm command show in that link.
- Check status of your helm package using **helm ls** command [click here to view](http://gitlab.products.kiya.ai/platform-km/grafana-promethehus-setup/-/blob/main/images/helmls.jpg)


